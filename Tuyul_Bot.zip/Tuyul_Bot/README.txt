
Welcome To Clickbot Ultimate Script

Commands

» pkg update && pkg upgrade -y
» pkg install python
» cd /sdcard/download/Telebot_Ultimate/Telebot_Ultimate/
»ls
» pip install -r requirements.txt
» python bot.py + (ur number)

Subscribe To My channel 

Sharif-Tricks
